import { useState } from "react";
import { LoginScreen } from "./components/LoginScreen";
import { ProfileSetup } from "./components/ProfileSetup";
import { IQTest } from "./components/IQTest";
import { HandwritingUpload } from "./components/HandwritingUpload";
import { AnalysisResults } from "./components/AnalysisResults";
import { RiskResult } from "./components/RiskResult";
import { ExerciseHome } from "./components/ExerciseHome";
import { ReportsScreen } from "./components/ReportsScreen";
import { SettingsScreen } from "./components/SettingsScreen";

type Screen = 
  | "login" 
  | "profile" 
  | "iqtest" 
  | "upload" 
  | "analysis" 
  | "risk" 
  | "exercises"
  | "reports"
  | "settings";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("login");
  const [childProfile, setChildProfile] = useState<{
    name: string;
    age: string;
    grade: string;
  } | null>(null);

  return (
    <div className="min-h-screen">
      {currentScreen === "login" && (
        <LoginScreen onLogin={() => setCurrentScreen("profile")} />
      )}
      
      {currentScreen === "profile" && (
        <ProfileSetup 
          onComplete={(profile) => {
            setChildProfile(profile);
            setCurrentScreen("iqtest");
          }}
          onBack={() => setCurrentScreen("login")}
        />
      )}
      
      {currentScreen === "iqtest" && (
        <IQTest onComplete={() => setCurrentScreen("upload")} />
      )}
      
      {currentScreen === "upload" && (
        <HandwritingUpload onAnalyze={() => setCurrentScreen("analysis")} />
      )}
      
      {currentScreen === "analysis" && (
        <AnalysisResults onContinue={() => setCurrentScreen("risk")} />
      )}
      
      {currentScreen === "risk" && (
        <RiskResult 
          onContinue={() => setCurrentScreen("exercises")}
          riskLevel="medium"
        />
      )}
      
      {currentScreen === "exercises" && (
        <ExerciseHome 
          childName={childProfile?.name || "Alex"}
          onNavigate={setCurrentScreen}
        />
      )}
      
      {currentScreen === "reports" && (
        <ReportsScreen onBack={() => setCurrentScreen("exercises")} />
      )}
      
      {currentScreen === "settings" && (
        <SettingsScreen onBack={() => setCurrentScreen("exercises")} />
      )}
    </div>
  );
}