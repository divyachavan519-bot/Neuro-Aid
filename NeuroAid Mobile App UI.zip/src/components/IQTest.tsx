import { useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, Check } from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { ProgressBar } from "./ProgressBar";
import { Mascot } from "./Mascot";

interface IQTestProps {
  onComplete: () => void;
}

// Mock Raven's Progressive Matrices questions
const questions = [
  {
    id: 1,
    pattern: "3x3 grid with shapes",
    options: ["A", "B", "C", "D", "E", "F"]
  },
  {
    id: 2,
    pattern: "3x3 grid with patterns",
    options: ["A", "B", "C", "D", "E", "F"]
  },
  {
    id: 3,
    pattern: "3x3 grid with symbols",
    options: ["A", "B", "C", "D", "E", "F"]
  }
];

export function IQTest({ onComplete }: IQTestProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [answers, setAnswers] = useState<string[]>([]);
  
  const handleNext = () => {
    if (selectedAnswer) {
      setAnswers([...answers, selectedAnswer]);
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        onComplete();
      }
    }
  };
  
  const question = questions[currentQuestion];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#F0FBE8] p-6 pt-12">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-[#002D72] mb-4 text-center">IQ Pattern Test</h2>
          <ProgressBar 
            current={currentQuestion + 1} 
            total={questions.length} 
            color="primary"
          />
        </div>
        
        {/* Mascot with encouragement */}
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex justify-center mb-6"
        >
          <Mascot 
            expression="encouraging" 
            message="You got this! Pick the right pattern!"
            size="md"
          />
        </motion.div>
        
        {/* Question Pattern */}
        <Card className="mb-6">
          <div className="mb-4 text-center">
            <p className="text-[#002D72] opacity-70 mb-4">
              Question {currentQuestion + 1} of {questions.length}
            </p>
            <h3 className="text-[#002D72] mb-6">Which pattern completes the sequence?</h3>
          </div>
          
          {/* Mock Pattern Display */}
          <div className="bg-gradient-to-br from-[#F5F9FF] to-[#FFF9E6] rounded-2xl p-8 mb-6">
            <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((cell) => (
                <div
                  key={cell}
                  className="aspect-square rounded-xl bg-white shadow-soft flex items-center justify-center"
                >
                  {cell === 9 ? (
                    <div className="text-4xl text-[#3D8BFF]">?</div>
                  ) : (
                    <div 
                      className="w-8 h-8 rounded-full"
                      style={{
                        background: `linear-gradient(${cell * 45}deg, #3D8BFF, #7BC950)`
                      }}
                    />
                  )}
                </div>
              ))}
              <div className="aspect-square rounded-xl bg-[#FFD23F] bg-opacity-20 flex items-center justify-center border-2 border-dashed border-[#FFD23F]">
                <div className="text-4xl text-[#FFD23F]">?</div>
              </div>
            </div>
          </div>
          
          {/* Answer Options */}
          <div className="grid grid-cols-3 gap-4">
            {question.options.map((option) => (
              <motion.button
                key={option}
                onClick={() => setSelectedAnswer(option)}
                className={`
                  aspect-square rounded-2xl flex flex-col items-center justify-center
                  transition-all duration-200 relative
                  ${selectedAnswer === option
                    ? "bg-[#3D8BFF] shadow-medium scale-105"
                    : "bg-white shadow-soft hover:shadow-medium"
                  }
                `}
                whileHover={{ scale: selectedAnswer === option ? 1.05 : 1.02 }}
                whileTap={{ scale: 0.95 }}
              >
                <div 
                  className={`w-12 h-12 rounded-full mb-2 ${
                    selectedAnswer === option ? "bg-white" : "bg-gradient-to-br from-[#3D8BFF] to-[#7BC950]"
                  }`}
                />
                <span className={`text-lg ${
                  selectedAnswer === option ? "text-white" : "text-[#002D72]"
                }`}>
                  {option}
                </span>
                {selectedAnswer === option && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-[#7BC950] flex items-center justify-center shadow-medium"
                  >
                    <Check className="w-5 h-5 text-white" />
                  </motion.div>
                )}
              </motion.button>
            ))}
          </div>
        </Card>
        
        <Button
          onClick={handleNext}
          disabled={!selectedAnswer}
          variant="primary"
          size="lg"
          icon={<ArrowRight className="w-5 h-5" />}
          className="w-full"
        >
          {currentQuestion === questions.length - 1 ? "Complete Test" : "Next Question"}
        </Button>
      </div>
    </div>
  );
}
