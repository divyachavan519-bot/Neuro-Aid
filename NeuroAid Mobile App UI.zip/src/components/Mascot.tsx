import { motion } from "motion/react";

interface MascotProps {
  expression?: "happy" | "thinking" | "encouraging" | "concerned";
  message?: string;
  size?: "sm" | "md" | "lg";
  animate?: boolean;
}

export function Mascot({ 
  expression = "happy", 
  message, 
  size = "md",
  animate = true 
}: MascotProps) {
  const sizes = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32"
  };
  
  // Different speech bubble styles based on expression
  const bubbleStyles = {
    happy: {
      bg: "bg-gradient-to-br from-[#FFD23F] to-[#FFE066]",
      border: "border-[#FFD23F]",
      text: "text-[#002D72]",
      tailColor: "border-b-[#FFD23F]",
      shadow: "shadow-[0_8px_30px_rgba(255,210,63,0.3)]"
    },
    thinking: {
      bg: "bg-gradient-to-br from-[#A78BFA] to-[#C4B5FD]",
      border: "border-[#A78BFA]",
      text: "text-white",
      tailColor: "border-b-[#A78BFA]",
      shadow: "shadow-[0_8px_30px_rgba(167,139,250,0.3)]"
    },
    encouraging: {
      bg: "bg-gradient-to-br from-[#7BC950] to-[#9BE276]",
      border: "border-[#7BC950]",
      text: "text-white",
      tailColor: "border-b-[#7BC950]",
      shadow: "shadow-[0_8px_30px_rgba(123,201,80,0.3)]"
    },
    concerned: {
      bg: "bg-gradient-to-br from-[#FF9F43] to-[#FFC078]",
      border: "border-[#FF9F43]",
      text: "text-white",
      tailColor: "border-b-[#FF9F43]",
      shadow: "shadow-[0_8px_30px_rgba(255,159,67,0.3)]"
    }
  };
  
  const currentBubble = bubbleStyles[expression];
  
  return (
    <div className="flex flex-col items-center gap-3">
      <motion.div
        className={`${sizes[size]} relative`}
        animate={animate ? {
          y: [0, -8, 0],
          rotate: [0, -2, 0, 2, 0]
        } : {}}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        {/* Owl mascot */}
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Body */}
          <ellipse cx="50" cy="60" rx="30" ry="35" fill="#3D8BFF" />
          <ellipse cx="50" cy="65" rx="25" ry="28" fill="#5BA4FF" />
          
          {/* Wings */}
          <ellipse cx="25" cy="60" rx="12" ry="20" fill="#2E7AEE" transform="rotate(-15 25 60)" />
          <ellipse cx="75" cy="60" rx="12" ry="20" fill="#2E7AEE" transform="rotate(15 75 60)" />
          
          {/* Wing patterns */}
          <ellipse cx="25" cy="55" rx="6" ry="10" fill="#3D8BFF" transform="rotate(-15 25 55)" />
          <ellipse cx="75" cy="55" rx="6" ry="10" fill="#3D8BFF" transform="rotate(15 75 55)" />
          
          {/* Head */}
          <circle cx="50" cy="35" r="28" fill="#3D8BFF" />
          
          {/* Ear tufts */}
          <path d="M 30 15 Q 28 8 25 12 L 30 20 Z" fill="#2E7AEE" />
          <path d="M 70 15 Q 72 8 75 12 L 70 20 Z" fill="#2E7AEE" />
          
          {/* Eye patches (white circles) */}
          <circle cx="40" cy="35" r="12" fill="white" />
          <circle cx="60" cy="35" r="12" fill="white" />
          
          {/* Glasses */}
          <circle cx="40" cy="35" r="11" fill="none" stroke="#002D72" strokeWidth="2" />
          <circle cx="60" cy="35" r="11" fill="none" stroke="#002D72" strokeWidth="2" />
          <line x1="51" y1="35" x2="49" y2="35" stroke="#002D72" strokeWidth="2" />
          
          {/* Eyes */}
          <circle cx="40" cy="35" r="7" fill="#002D72" />
          <circle cx="60" cy="35" r="7" fill="#002D72" />
          
          {/* Eye expressions */}
          {expression === "happy" && (
            <>
              <circle cx="38" cy="33" r="3" fill="white" />
              <circle cx="58" cy="33" r="3" fill="white" />
            </>
          )}
          {expression === "thinking" && (
            <>
              <ellipse cx="40" cy="35" rx="5" ry="7" fill="#002D72" />
              <ellipse cx="60" cy="35" rx="5" ry="7" fill="#002D72" />
              <circle cx="39" cy="32" r="2" fill="white" />
              <circle cx="59" cy="32" r="2" fill="white" />
            </>
          )}
          {expression === "encouraging" && (
            <>
              <circle cx="37" cy="32" r="3.5" fill="white" />
              <circle cx="57" cy="32" r="3.5" fill="white" />
            </>
          )}
          {expression === "concerned" && (
            <>
              <circle cx="40" cy="36" r="2.5" fill="white" />
              <circle cx="60" cy="36" r="2.5" fill="white" />
            </>
          )}
          
          {/* Beak */}
          <path d="M 50 40 L 45 48 L 50 46 L 55 48 Z" fill="#FFD23F" />
          
          {/* Belly pattern */}
          <ellipse cx="50" cy="70" rx="15" ry="18" fill="#E8F4FF" opacity="0.6" />
          <path d="M 42 65 Q 50 68 58 65" stroke="#3D8BFF" strokeWidth="1.5" fill="none" />
          <path d="M 42 70 Q 50 73 58 70" stroke="#3D8BFF" strokeWidth="1.5" fill="none" />
          <path d="M 42 75 Q 50 78 58 75" stroke="#3D8BFF" strokeWidth="1.5" fill="none" />
          
          {/* Feet */}
          <g transform="translate(40, 88)">
            <line x1="0" y1="0" x2="-3" y2="5" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
            <line x1="0" y1="0" x2="0" y2="6" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
            <line x1="0" y1="0" x2="3" y2="5" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
          </g>
          <g transform="translate(60, 88)">
            <line x1="0" y1="0" x2="-3" y2="5" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
            <line x1="0" y1="0" x2="0" y2="6" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
            <line x1="0" y1="0" x2="3" y2="5" stroke="#FFD23F" strokeWidth="2" strokeLinecap="round" />
          </g>
          
          {/* Book prop */}
          {expression === "thinking" && (
            <g transform="translate(75, 70) rotate(20)">
              <rect x="0" y="0" width="12" height="16" fill="#7BC950" rx="1" />
              <rect x="1" y="1" width="10" height="14" fill="#9BE276" rx="1" />
              <line x1="6" y1="0" x2="6" y2="16" stroke="#7BC950" strokeWidth="1" />
            </g>
          )}
        </svg>
      </motion.div>
      
      {message && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          className="relative max-w-xs"
        >
          {/* Interesting speech bubble with gradient and decorations */}
          <motion.div
            className={`${currentBubble.bg} ${currentBubble.shadow} px-5 py-3 rounded-3xl border-3 ${currentBubble.border} relative`}
            animate={{
              scale: [1, 1.02, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {/* Bubble tail - rounded style */}
            <div className={`absolute -top-3 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[12px] border-r-[12px] border-b-[12px] border-transparent ${currentBubble.tailColor}`} />
            
            {/* Decorative dots */}
            <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-white opacity-60" />
            <div className="absolute -bottom-1 -left-1 w-2 h-2 rounded-full bg-white opacity-40" />
            
            {/* Message text */}
            <p className={`${currentBubble.text} text-center relative z-10`}>
              {message}
            </p>
            
            {/* Sparkle decoration for happy expressions */}
            {expression === "happy" && (
              <>
                <motion.div
                  className="absolute -top-2 -right-2 text-white text-lg"
                  animate={{
                    rotate: [0, 360],
                    scale: [1, 1.2, 1]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  ✨
                </motion.div>
                <motion.div
                  className="absolute -bottom-2 -left-2 text-white text-sm"
                  animate={{
                    rotate: [360, 0],
                    scale: [1, 1.3, 1]
                  }}
                  transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }}
                >
                  ⭐
                </motion.div>
              </>
            )}
            
            {/* Thought bubbles for thinking expression */}
            {expression === "thinking" && (
              <>
                <motion.div
                  className="absolute -left-4 top-0 w-2 h-2 rounded-full bg-[#A78BFA]"
                  animate={{
                    opacity: [0.3, 1, 0.3],
                    scale: [0.8, 1, 0.8]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />
                <motion.div
                  className="absolute -left-7 -top-2 w-3 h-3 rounded-full bg-[#A78BFA]"
                  animate={{
                    opacity: [0.2, 0.8, 0.2],
                    scale: [0.7, 1, 0.7]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: 0.3
                  }}
                />
              </>
            )}
            
            {/* Concerned indicator */}
            {expression === "concerned" && (
              <motion.div
                className="absolute -top-2 left-2 text-xl"
                animate={{
                  rotate: [-10, 10, -10],
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                🤔
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}