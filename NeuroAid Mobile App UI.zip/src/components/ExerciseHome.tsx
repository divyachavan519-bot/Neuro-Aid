import { useState } from "react";
import { motion } from "motion/react";
import { 
  Puzzle, 
  PenTool, 
  Book, 
  Download, 
  Lightbulb, 
  Trophy,
  Flame,
  Star,
  TrendingUp,
  Play,
  Lock,
  StickyNote,
  Settings,
  BarChart3,
  CheckCircle
} from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Badge } from "./Badge";
import { Mascot } from "./Mascot";
import logoImage from "figma:asset/7b9e7801142adf23c6d174d187ccc892b0e83461.png";

interface Exercise {
  id: string;
  title: string;
  description: string;
  icon: JSX.Element;
  difficulty: "easy" | "medium" | "hard";
  completed: boolean;
  locked: boolean;
  color: string;
}

interface ExerciseHomeProps {
  childName: string;
  onNavigate: (screen: "reports" | "settings") => void;
}

export function ExerciseHome({ childName, onNavigate }: ExerciseHomeProps) {
  const [streak, setStreak] = useState(7);
  const [coins, setCoins] = useState(450);
  const [handwritingScore, setHandwritingScore] = useState(78);
  const [showConfetti, setShowConfetti] = useState(false);
  
  const [exercises, setExercises] = useState<Exercise[]>([
    {
      id: "letter-matching",
      title: "Letter Matching",
      description: "Drag letters to their correct positions",
      icon: <Puzzle className="w-6 h-6" />,
      difficulty: "easy",
      completed: false,
      locked: false,
      color: "from-[#7BC950] to-[#9BE276]"
    },
    {
      id: "letter-tracing",
      title: "Letter Tracing",
      description: "Practice writing letters step by step",
      icon: <PenTool className="w-6 h-6" />,
      difficulty: "medium",
      completed: false,
      locked: false,
      color: "from-[#3D8BFF] to-[#5BA4FF]"
    },
    {
      id: "word-building",
      title: "Word Building",
      description: "Build words from letter blocks",
      icon: <Book className="w-6 h-6" />,
      difficulty: "medium",
      completed: false,
      locked: false,
      color: "from-[#FFD23F] to-[#FFE066]"
    }
  ]);
  
  const handleSubmitExercise = (exerciseId: string) => {
    setExercises(prev => 
      prev.map(ex => 
        ex.id === exerciseId 
          ? { ...ex, completed: true }
          : ex
      )
    );
    
    // Update streak and coins
    setStreak(prev => prev + 1);
    setCoins(prev => prev + 50);
    setHandwritingScore(prev => Math.min(100, prev + 2));
    
    // Show confetti animation
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 3000);
  };
  
  const completedCount = exercises.filter(ex => ex.completed).length;
  const totalExercises = exercises.length;
  const progressPercentage = Math.round((completedCount / totalExercises) * 100);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#F0FBE8] pb-20">
      {/* Confetti Animation */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-50">
          {Array.from({ length: 30 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute"
              initial={{ 
                top: "50%", 
                left: "50%",
                opacity: 1,
                scale: 1
              }}
              animate={{ 
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: 0,
                scale: 0,
                rotate: Math.random() * 360
              }}
              transition={{
                duration: 2,
                ease: "easeOut"
              }}
            >
              <div 
                className="w-3 h-3 rounded-full"
                style={{
                  backgroundColor: ['#FFD23F', '#7BC950', '#3D8BFF', '#FF9F43'][Math.floor(Math.random() * 4)]
                }}
              />
            </motion.div>
          ))}
        </div>
      )}
      
      {/* Header */}
      <div className="bg-gradient-to-br from-[#3D8BFF] to-[#5BA4FF] pt-12 pb-8 px-6 rounded-b-[3rem] shadow-strong">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <img src={logoImage} alt="NeuroAid" className="w-12 h-12" />
            <div className="flex gap-2">
              <motion.button
                onClick={() => onNavigate("reports")}
                className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full p-3 flex items-center justify-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <BarChart3 className="w-5 h-5 text-white" />
              </motion.button>
              <motion.button
                onClick={() => onNavigate("settings")}
                className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full p-3 flex items-center justify-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Settings className="w-5 h-5 text-white" />
              </motion.button>
            </div>
          </div>
          
          <div className="flex items-center justify-between mb-6">
            <div className="flex gap-3">
              <motion.div
                className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2"
                whileHover={{ scale: 1.05 }}
              >
                <Flame className="w-5 h-5 text-[#FFD23F]" />
                <span className="text-white">{streak} days</span>
              </motion.div>
              <motion.div
                className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2"
                whileHover={{ scale: 1.05 }}
              >
                <Trophy className="w-5 h-5 text-[#FFD23F]" />
                <span className="text-white">{coins}</span>
              </motion.div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0">
              <Mascot expression="happy" size="md" animate={false} />
            </div>
            <div className="flex-1">
              <h2 className="text-white mb-2">Welcome, {childName}!</h2>
              <p className="text-white text-opacity-90 text-sm">
                Ready for today's practice?
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-2xl mx-auto px-6 -mt-8">
        {/* Handwriting Score Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card gradient className="mb-6 border-2 border-[#3D8BFF]">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-[#002D72] mb-1">Handwriting Score</h3>
                <p className="text-sm text-[#002D72] opacity-60">Keep practicing to improve!</p>
              </div>
              <div className="relative">
                <svg className="w-20 h-20 transform -rotate-90">
                  <circle
                    cx="40"
                    cy="40"
                    r="34"
                    stroke="#E5E7EB"
                    strokeWidth="6"
                    fill="none"
                  />
                  <motion.circle
                    cx="40"
                    cy="40"
                    r="34"
                    stroke="#3D8BFF"
                    strokeWidth="6"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 34}`}
                    initial={{ strokeDashoffset: 2 * Math.PI * 34 }}
                    animate={{ strokeDashoffset: 2 * Math.PI * 34 * (1 - handwritingScore / 100) }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[#002D72]">{handwritingScore}</span>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Daily Streak Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card gradient className="mb-6 border-2 border-[#FFD23F]">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#FFD23F] to-[#FFE066] flex items-center justify-center flex-shrink-0 shadow-soft">
                <Flame className="w-8 h-8 text-[#002D72]" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-[#002D72]">Daily Streak 🔥</h3>
                  <Badge variant="warning">{streak} days</Badge>
                </div>
                <p className="text-sm text-[#002D72] opacity-60">
                  {completedCount} of {totalExercises} exercises completed today
                </p>
                <div className="h-3 bg-gray-200 rounded-full overflow-hidden mt-3">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#FFD23F] to-[#FFE066]"
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPercentage}%` }}
                    transition={{ duration: 0.8 }}
                  />
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Parent Notes Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="mb-6 bg-gradient-to-br from-[#FFF9E6] to-[#FFF4D6] border-2 border-[#FFD23F]">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-full bg-[#FFD23F] flex items-center justify-center flex-shrink-0">
                <StickyNote className="w-6 h-6 text-[#002D72]" />
              </div>
              <div className="flex-1">
                <h3 className="text-[#002D72] mb-2">Parent Notes</h3>
                <p className="text-sm text-[#002D72] opacity-80 mb-3">
                  {childName} is showing great improvement in letter spacing and consistency. Keep encouraging daily practice for best results!
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="info">Letter Formation: Good</Badge>
                  <Badge variant="success">Consistency: Improved</Badge>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Exercises Section */}
        <div className="mb-6">
          <h3 className="text-[#002D72] mb-4">Today's Practice Exercises</h3>
          <div className="space-y-4">
            {exercises.map((exercise, index) => (
              <motion.div
                key={exercise.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card 
                  hoverable={!exercise.locked} 
                  className={`relative overflow-hidden ${exercise.locked ? "opacity-60" : ""}`}
                >
                  <div className={`absolute top-0 left-0 w-2 h-full bg-gradient-to-b ${exercise.color}`} />
                  
                  <div className="flex items-center gap-4 pl-4">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${exercise.color} flex items-center justify-center text-white shadow-soft flex-shrink-0`}>
                      {exercise.locked ? <Lock className="w-6 h-6" /> : exercise.icon}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-[#002D72]">{exercise.title}</h3>
                        {exercise.completed && (
                          <Badge variant="success" icon={<CheckCircle className="w-3 h-3" />}>
                            Complete
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-[#002D72] opacity-60 mb-2">
                        {exercise.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <div className={`
                          px-2 py-1 rounded-full text-xs
                          ${exercise.difficulty === "easy" ? "bg-[#7BC950] text-white" :
                            exercise.difficulty === "medium" ? "bg-[#FFD23F] text-[#002D72]" :
                            "bg-[#FF9F43] text-white"}
                        `}>
                          {exercise.difficulty}
                        </div>
                        {!exercise.completed && (
                          <div className="text-xs text-[#7BC950]">+50 coins</div>
                        )}
                      </div>
                    </div>
                    
                    {!exercise.locked && (
                      <Button
                        onClick={() => handleSubmitExercise(exercise.id)}
                        variant={exercise.completed ? "outline" : "primary"}
                        size="sm"
                        icon={exercise.completed ? <CheckCircle className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        disabled={exercise.completed}
                      >
                        {exercise.completed ? "Done" : "Submit"}
                      </Button>
                    )}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card hoverable className="text-center" onClick={() => onNavigate("reports")}>
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#3D8BFF] to-[#5BA4FF] flex items-center justify-center mx-auto mb-3">
              <Download className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-[#002D72] mb-1 text-sm">Progress Report</h3>
            <p className="text-xs text-[#002D72] opacity-60">View & Download</p>
          </Card>
          
          <Card hoverable className="text-center">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#FFD23F] to-[#FFE066] flex items-center justify-center mx-auto mb-3">
              <Lightbulb className="w-7 h-7 text-[#002D72]" />
            </div>
            <h3 className="text-[#002D72] mb-1 text-sm">Parent Tips</h3>
            <p className="text-xs text-[#002D72] opacity-60">View guidance</p>
          </Card>
        </div>
        
        {/* Daily Goal Summary */}
        <Card gradient className="border-2 border-[#7BC950]">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#7BC950] flex items-center justify-center flex-shrink-0">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-[#002D72] mb-1">Daily Goal</h3>
              <p className="text-sm text-[#002D72] opacity-60">
                {completedCount} of {totalExercises} exercises completed
              </p>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden mt-2">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#7BC950] to-[#9BE276]"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </div>
            <Badge variant="success">{progressPercentage}%</Badge>
          </div>
        </Card>
      </div>
    </div>
  );
}
