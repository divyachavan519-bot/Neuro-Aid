import { motion } from "motion/react";
import { ReactNode } from "react";

interface BadgeProps {
  children: ReactNode;
  variant: "low" | "medium" | "high" | "success" | "info";
  icon?: ReactNode;
  pulse?: boolean;
}

export function Badge({ children, variant, icon, pulse = false }: BadgeProps) {
  const variants = {
    low: "bg-[#7BC950] text-white",
    medium: "bg-[#FFD23F] text-[#002D72]",
    high: "bg-[#FF6B6B] text-white",
    success: "bg-[#7BC950] text-white",
    info: "bg-[#3D8BFF] text-white"
  };
  
  return (
    <motion.div
      className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${variants[variant]} shadow-soft`}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: "spring", stiffness: 500, damping: 25 }}
    >
      {icon && (
        <motion.span
          animate={pulse ? { scale: [1, 1.2, 1] } : {}}
          transition={{ duration: 1, repeat: Infinity }}
        >
          {icon}
        </motion.span>
      )}
      <span>{children}</span>
    </motion.div>
  );
}
