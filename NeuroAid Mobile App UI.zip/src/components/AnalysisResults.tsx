import { motion } from "motion/react";
import { AlertCircle, ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Badge } from "./Badge";
import { Mascot } from "./Mascot";

interface AnalysisResultsProps {
  onContinue: () => void;
}

interface AnalysisItem {
  id: string;
  label: string;
  severity: "low" | "medium" | "high";
  description: string;
  icon: string;
}

const analysisData: AnalysisItem[] = [
  {
    id: "reversal",
    label: "Letter Reversals",
    severity: "medium",
    description: "Some letters written backwards (b/d, p/q)",
    icon: "🔄"
  },
  {
    id: "mirroring",
    label: "Mirroring",
    severity: "low",
    description: "Occasional mirror writing detected",
    icon: "🪞"
  },
  {
    id: "spacing",
    label: "Letter Spacing",
    severity: "high",
    description: "Inconsistent spacing between letters",
    icon: "↔️"
  },
  {
    id: "strokes",
    label: "Stroke Quality",
    severity: "medium",
    description: "Irregular stroke patterns observed",
    icon: "✏️"
  }
];

export function AnalysisResults({ onContinue }: AnalysisResultsProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#FFF9E6] p-6 pt-12">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h2 className="text-[#002D72] mb-2">Analysis Complete</h2>
          <p className="text-[#002D72] opacity-70">
            Here's what we found
          </p>
        </div>
        
        {/* Mascot */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex justify-center mb-8"
        >
          <Mascot 
            expression="thinking" 
            message="Let me show you what I found!"
            size="md"
          />
        </motion.div>
        
        {/* Analysis Results */}
        <div className="space-y-4 mb-6">
          {analysisData.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card hoverable>
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{item.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-[#002D72]">{item.label}</h3>
                      <Badge 
                        variant={item.severity}
                        icon={
                          item.severity === "low" ? <CheckCircle className="w-4 h-4" /> :
                          <AlertCircle className="w-4 h-4" />
                        }
                      >
                        {item.severity === "low" ? "Good" :
                         item.severity === "medium" ? "Moderate" :
                         "Needs Work"}
                      </Badge>
                    </div>
                    <p className="text-sm text-[#002D72] opacity-70">
                      {item.description}
                    </p>
                  </div>
                </div>
                
                {/* Visual Progress Bar */}
                <div className="mt-4 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full ${
                      item.severity === "low" ? "bg-[#7BC950]" :
                      item.severity === "medium" ? "bg-[#FFD23F]" :
                      "bg-[#FF6B6B]"
                    }`}
                    initial={{ width: 0 }}
                    animate={{ 
                      width: item.severity === "low" ? "25%" :
                             item.severity === "medium" ? "50%" :
                             "75%"
                    }}
                    transition={{ delay: index * 0.1 + 0.3, duration: 0.5 }}
                  />
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
        
        {/* Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card gradient className="mb-6 border-2 border-[#3D8BFF]">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-[#3D8BFF] flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-[#002D72] mb-2">Overall Assessment</h3>
              <p className="text-[#002D72] opacity-70 mb-4">
                The analysis shows some areas that could benefit from targeted exercises.
                Let's see the detailed risk assessment!
              </p>
            </div>
          </Card>
        </motion.div>
        
        <Button
          onClick={onContinue}
          variant="primary"
          size="lg"
          icon={<ArrowRight className="w-5 h-5" />}
          className="w-full"
        >
          View Risk Assessment
        </Button>
      </div>
    </div>
  );
}
