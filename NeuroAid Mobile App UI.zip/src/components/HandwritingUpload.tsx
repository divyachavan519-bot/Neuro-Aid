import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Camera, Upload, Image, Sparkles, ArrowRight } from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Mascot } from "./Mascot";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HandwritingUploadProps {
  onAnalyze: () => void;
}

export function HandwritingUpload({ onAnalyze }: HandwritingUploadProps) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showFallback, setShowFallback] = useState(false);
  
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setShowFallback(false);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // Simulate AI detection - 30% chance of failing to detect
    const detectionSuccess = Math.random() > 0.3;
    
    setTimeout(() => {
      if (!detectionSuccess) {
        setShowFallback(true);
        setIsAnalyzing(false);
      } else {
        onAnalyze();
      }
    }, 3000);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#FFF9E6] p-6 pt-12">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h2 className="text-[#002D72] mb-2">Handwriting Analysis</h2>
          <p className="text-[#002D72] opacity-70">
            Upload a photo of the child's handwriting
          </p>
        </div>
        
        {/* Mascot */}
        {!isAnalyzing && !showFallback && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-6"
          >
            <Mascot 
              expression="thinking" 
              message={uploadedImage ? "Great! Let's analyze it!" : "Take a clear photo of the writing"}
              size="md"
            />
          </motion.div>
        )}
        
        <AnimatePresence mode="wait">
          {showFallback ? (
            <motion.div
              key="fallback"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="flex justify-center mb-6">
                <Mascot 
                  expression="concerned" 
                  message="Let's try something different!"
                  size="md"
                />
              </div>
              
              <Card className="mb-6 bg-gradient-to-br from-[#FFF9E6] to-[#FFF4D6] border-2 border-[#FFD23F]">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-[#FF9F43] flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-[#002D72] mb-2">AI couldn't detect handwriting clearly</h3>
                    <p className="text-sm text-[#002D72] opacity-70">
                      No worries! Please have the child rewrite the following text on a clean sheet of paper, then take a new photo.
                    </p>
                  </div>
                </div>
                
                <Card gradient className="bg-white border-2 border-[#3D8BFF]">
                  <h3 className="text-[#002D72] mb-3">Please write this:</h3>
                  <div className="space-y-3">
                    <p className="text-[#002D72] leading-relaxed">
                      The quick brown fox jumps over the lazy dog. This sentence helps us practice different letter shapes and sizes.
                    </p>
                    <p className="text-[#002D72] leading-relaxed">
                      Writing clearly takes practice, but every day you get better at forming letters and words with care.
                    </p>
                    <p className="text-[#002D72] leading-relaxed">
                      Remember to take your time and focus on making each letter neat and easy to read.
                    </p>
                    <div className="border-t-2 border-dashed border-[#3D8BFF] my-3 pt-3">
                      <p className="text-[#002D72]">
                        Numbers to write: <span className="text-[#3D8BFF]">1234567890</span>
                      </p>
                    </div>
                  </div>
                </Card>
              </Card>
              
              <Button
                onClick={() => {
                  setUploadedImage(null);
                  setShowFallback(false);
                }}
                variant="primary"
                size="lg"
                icon={<Camera className="w-5 h-5" />}
                className="w-full"
              >
                Take New Photo
              </Button>
            </motion.div>
          ) : !uploadedImage ? (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {/* Upload Options */}
              <div className="grid grid-cols-1 gap-4 mb-6">
                <Card hoverable className="cursor-pointer">
                  <label className="flex flex-col items-center cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#3D8BFF] to-[#5BA4FF] flex items-center justify-center mb-4">
                      <Camera className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-[#002D72] mb-2">Take Photo</h3>
                    <p className="text-[#002D72] opacity-60 text-center text-sm">
                      Use your camera to capture handwriting
                    </p>
                  </label>
                </Card>
                
                <Card hoverable className="cursor-pointer">
                  <label className="flex flex-col items-center cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#FFD23F] to-[#FFE066] flex items-center justify-center mb-4">
                      <Image className="w-10 h-10 text-[#002D72]" />
                    </div>
                    <h3 className="text-[#002D72] mb-2">Choose from Gallery</h3>
                    <p className="text-[#002D72] opacity-60 text-center text-sm">
                      Select an existing photo
                    </p>
                  </label>
                </Card>
              </div>
              
              {/* Sample Guidelines */}
              <Card gradient>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#3D8BFF] flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-[#002D72] mb-2">Tips for best results</h3>
                    <ul className="text-sm text-[#002D72] opacity-70 space-y-1">
                      <li>• Ensure good lighting</li>
                      <li>• Capture the full page</li>
                      <li>• Keep the camera steady</li>
                      <li>• Avoid shadows on paper</li>
                    </ul>
                  </div>
                </div>
              </Card>
            </motion.div>
          ) : !isAnalyzing ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              {/* Preview */}
              <Card className="mb-6">
                <div className="mb-4">
                  <h3 className="text-[#002D72] mb-4">Preview</h3>
                  <div className="relative rounded-2xl overflow-hidden bg-gray-100">
                    <img 
                      src={uploadedImage} 
                      alt="Uploaded handwriting" 
                      className="w-full h-auto"
                    />
                  </div>
                </div>
                
                <button
                  onClick={() => setUploadedImage(null)}
                  className="text-[#3D8BFF] text-sm underline"
                >
                  Upload different image
                </button>
              </Card>
              
              <Button
                onClick={handleAnalyze}
                variant="primary"
                size="lg"
                icon={<Sparkles className="w-5 h-5" />}
                className="w-full"
              >
                Analyze with AI
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="analyzing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16"
            >
              <div className="relative mb-8">
                <div className="w-64 h-64 rounded-3xl overflow-hidden bg-gray-100 relative">
                  <img 
                    src={uploadedImage} 
                    alt="Analyzing" 
                    className="w-full h-full object-cover"
                  />
                  {/* Scanning animation */}
                  <motion.div
                    className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#3D8BFF] to-transparent"
                    animate={{
                      top: ["0%", "100%"]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />
                  <div className="absolute inset-0 border-4 border-[#3D8BFF] rounded-3xl" />
                </div>
              </div>
              
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="mb-4"
              >
                <Sparkles className="w-12 h-12 text-[#3D8BFF]" />
              </motion.div>
              
              <h3 className="text-[#002D72] mb-2">Analyzing Handwriting...</h3>
              <p className="text-[#002D72] opacity-60 text-center">
                Our AI is examining patterns, spacing, and letter formation
              </p>
              
              <motion.div
                className="flex gap-2 mt-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-3 h-3 rounded-full bg-[#3D8BFF]"
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5]
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.2
                    }}
                  />
                ))}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}