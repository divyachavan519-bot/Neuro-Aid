import { useState } from "react";
import { motion } from "motion/react";
import { Mail, ArrowRight } from "lucide-react";
import { Button } from "./Button";
import { Mascot } from "./Mascot";
import logoImage from "figma:asset/7b9e7801142adf23c6d174d187ccc892b0e83461.png";

interface LoginScreenProps {
  onLogin: () => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState("");
  const [focused, setFocused] = useState(false);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#FFF9E6] flex flex-col items-center justify-center p-6">
      {/* Logo */}
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-8"
      >
        <img src={logoImage} alt="NeuroAid" className="w-32 h-32" />
      </motion.div>
      
      {/* Mascot */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="mb-6"
      >
        <Mascot expression="happy" size="lg" />
      </motion.div>
      
      {/* Tagline */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="text-center mb-8"
      >
        <p className="text-[#002D72] opacity-80">Helping young minds write their future</p>
      </motion.div>
      
      {/* Login Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="w-full max-w-md"
      >
        <div className="bg-white rounded-3xl p-8 shadow-medium">
          <h2 className="text-[#002D72] mb-6 text-center">Welcome Back!</h2>
          
          <div className="mb-6">
            <label className="block text-[#002D72] mb-2 text-sm">Email Address</label>
            <div className={`
              relative flex items-center bg-[#F5F9FF] rounded-2xl px-4 py-3
              border-2 transition-all duration-200
              ${focused ? "border-[#3D8BFF] shadow-soft" : "border-transparent"}
            `}>
              <Mail className="w-5 h-5 text-[#3D8BFF] mr-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
                placeholder="parent@email.com"
                className="flex-1 bg-transparent outline-none text-[#002D72]"
              />
            </div>
          </div>
          
          <Button
            onClick={onLogin}
            variant="primary"
            size="lg"
            icon={<ArrowRight className="w-5 h-5" />}
            className="w-full"
          >
            Continue into NeuroAid
          </Button>
          
          <p className="text-center text-sm text-[#002D72] opacity-60 mt-4">
            For Parents & Teachers
          </p>
        </div>
      </motion.div>
      
      {/* Decorative Elements */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 right-10 w-16 h-16 rounded-full bg-[#FFD23F] opacity-20"
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-20 left-10 w-20 h-20 rounded-full bg-[#7BC950] opacity-20"
      />
    </div>
  );
}
