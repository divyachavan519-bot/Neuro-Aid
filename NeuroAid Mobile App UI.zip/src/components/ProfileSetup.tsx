import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { User, Calendar, BookOpen, ArrowRight, ArrowLeft } from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { ProgressBar } from "./ProgressBar";
import { Mascot } from "./Mascot";

interface ProfileSetupProps {
  onComplete: (profile: { name: string; age: string; grade: string }) => void;
  onBack: () => void;
}

export function ProfileSetup({ onComplete, onBack }: ProfileSetupProps) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [grade, setGrade] = useState("");
  const [focusedField, setFocusedField] = useState("");
  
  const totalSteps = 3;
  
  const grades = ["Grade 2", "Grade 3", "Grade 4", "Grade 5"];
  
  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete({ name, age, grade });
    }
  };
  
  const canProceed = 
    (step === 1 && name.trim() !== "") ||
    (step === 2 && age !== "") ||
    (step === 3 && grade !== "");
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#FFF9E6] p-6 pt-12">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={onBack}
            variant="outline"
            size="sm"
            icon={<ArrowLeft className="w-4 h-4" />}
            className="mb-6"
          >
            Back
          </Button>
          
          <ProgressBar current={step} total={totalSteps} />
        </div>
        
        {/* Mascot */}
        <motion.div
          key={step}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-6"
        >
          <Mascot 
            expression="encouraging" 
            message={
              step === 1 ? "What's your name?" :
              step === 2 ? "How old are you?" :
              "Which grade are you in?"
            }
            size="md"
          />
        </motion.div>
        
        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="mb-6">
              {step === 1 && (
                <div>
                  <div className="flex items-center justify-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-[#E8F4FF] flex items-center justify-center">
                      <User className="w-8 h-8 text-[#3D8BFF]" />
                    </div>
                  </div>
                  
                  <h2 className="text-[#002D72] text-center mb-6">Child's Name</h2>
                  
                  <div className={`
                    bg-[#F5F9FF] rounded-2xl px-4 py-4 border-2 transition-all duration-200
                    ${focusedField === "name" ? "border-[#3D8BFF] shadow-soft" : "border-transparent"}
                  `}>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      onFocus={() => setFocusedField("name")}
                      onBlur={() => setFocusedField("")}
                      placeholder="Enter name"
                      className="w-full bg-transparent outline-none text-[#002D72] text-lg text-center"
                    />
                  </div>
                </div>
              )}
              
              {step === 2 && (
                <div>
                  <div className="flex items-center justify-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-[#FFF9E6] flex items-center justify-center">
                      <Calendar className="w-8 h-8 text-[#FFD23F]" />
                    </div>
                  </div>
                  
                  <h2 className="text-[#002D72] text-center mb-6">Child's Age</h2>
                  
                  <div className="grid grid-cols-5 gap-3">
                    {[7, 8, 9, 10, 11].map((ageOption) => (
                      <motion.button
                        key={ageOption}
                        onClick={() => setAge(ageOption.toString())}
                        className={`
                          aspect-square rounded-2xl text-2xl transition-all duration-200
                          ${age === ageOption.toString()
                            ? "bg-[#FFD23F] text-[#002D72] shadow-medium scale-110"
                            : "bg-[#F5F9FF] text-[#002D72] opacity-60 hover:opacity-100"
                          }
                        `}
                        whileHover={{ scale: age === ageOption.toString() ? 1.1 : 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {ageOption}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
              
              {step === 3 && (
                <div>
                  <div className="flex items-center justify-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-[#F0FBE8] flex items-center justify-center">
                      <BookOpen className="w-8 h-8 text-[#7BC950]" />
                    </div>
                  </div>
                  
                  <h2 className="text-[#002D72] text-center mb-6">School Grade</h2>
                  
                  <div className="space-y-3">
                    {grades.map((gradeOption) => (
                      <motion.button
                        key={gradeOption}
                        onClick={() => setGrade(gradeOption)}
                        className={`
                          w-full py-4 rounded-2xl text-lg transition-all duration-200
                          ${grade === gradeOption
                            ? "bg-[#7BC950] text-white shadow-medium"
                            : "bg-[#F5F9FF] text-[#002D72] hover:bg-[#E8F4FF]"
                          }
                        `}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        {gradeOption}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
            </Card>
            
            <Button
              onClick={handleNext}
              disabled={!canProceed}
              variant={step === totalSteps ? "success" : "primary"}
              size="lg"
              icon={<ArrowRight className="w-5 h-5" />}
              className="w-full"
            >
              {step === totalSteps ? "Start IQ Test" : "Continue"}
            </Button>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
