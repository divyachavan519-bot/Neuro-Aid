import { motion } from "motion/react";

interface ProgressBarProps {
  current: number;
  total: number;
  showLabel?: boolean;
  color?: "primary" | "success" | "warning";
}

export function ProgressBar({ 
  current, 
  total, 
  showLabel = true,
  color = "primary" 
}: ProgressBarProps) {
  const percentage = (current / total) * 100;
  
  const colors = {
    primary: "bg-[#3D8BFF]",
    success: "bg-[#7BC950]",
    warning: "bg-[#FFD23F]"
  };
  
  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex justify-between mb-2">
          <span className="text-sm text-[#002D72] opacity-70">Progress</span>
          <span className="text-sm text-[#002D72]">{current}/{total}</span>
        </div>
      )}
      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
        <motion.div
          className={`h-full ${colors[color]} rounded-full`}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
