import { useState } from "react";
import { motion } from "motion/react";
import { 
  ArrowLeft, 
  Download, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Calendar,
  FileText
} from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Badge } from "./Badge";
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Area,
  AreaChart 
} from "recharts";

interface ReportsScreenProps {
  onBack: () => void;
}

// Mock data for charts
const scoreData = [
  { date: "Nov 10", score: 65, difficulty: 1 },
  { date: "Nov 12", score: 68, difficulty: 1 },
  { date: "Nov 14", score: 72, difficulty: 2 },
  { date: "Nov 16", score: 70, difficulty: 2 },
  { date: "Nov 18", score: 75, difficulty: 2 },
  { date: "Nov 20", score: 78, difficulty: 2 },
  { date: "Nov 22", score: 80, difficulty: 3 }
];

const categoryData = [
  { category: "Letter\nFormation", score: 85 },
  { category: "Spacing", score: 72 },
  { category: "Size\nConsistency", score: 78 },
  { category: "Line\nAlignment", score: 68 },
  { category: "Letter\nRecognition", score: 90 }
];

export function ReportsScreen({ onBack }: ReportsScreenProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month" | "all">("week");
  
  const alerts = [
    {
      id: 1,
      type: "warning",
      title: "Spacing Consistency",
      message: "Letter spacing has slightly decreased over the past 3 days",
      date: "Nov 20, 2025"
    },
    {
      id: 2,
      type: "success",
      title: "Great Progress!",
      message: "Letter formation improved by 15% this week",
      date: "Nov 18, 2025"
    }
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E0F7F7] via-[#E8F4FF] to-[#F0FBF8] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#14B8A6] to-[#3D8BFF] pt-12 pb-8 px-6 rounded-b-[3rem] shadow-strong">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <motion.button
              onClick={onBack}
              className="w-10 h-10 rounded-full bg-white bg-opacity-20 backdrop-blur-sm flex items-center justify-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </motion.button>
            <h2 className="text-white flex-1">Progress Reports</h2>
            <Button
              variant="outline"
              size="sm"
              icon={<Download className="w-4 h-4" />}
              className="bg-white text-[#14B8A6] border-white hover:bg-opacity-90"
            >
              Export PDF
            </Button>
          </div>
          
          <p className="text-white text-opacity-90 text-sm">
            Track your child's learning journey and improvement over time
          </p>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto px-6 -mt-8">
        {/* Period Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Card gradient className="border-2 border-[#14B8A6]">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#14B8A6]" />
              <span className="text-[#002D72] text-sm mr-3">Time Period:</span>
              <div className="flex gap-2 flex-1">
                {(["week", "month", "all"] as const).map((period) => (
                  <button
                    key={period}
                    onClick={() => setSelectedPeriod(period)}
                    className={`
                      flex-1 px-4 py-2 rounded-full text-sm transition-all
                      ${selectedPeriod === period
                        ? "bg-gradient-to-r from-[#14B8A6] to-[#3D8BFF] text-white shadow-soft"
                        : "bg-gray-100 text-[#002D72] hover:bg-gray-200"}
                    `}
                  >
                    {period === "week" ? "This Week" : period === "month" ? "This Month" : "All Time"}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Overall Score Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-white to-[#E0F7F7] border-2 border-[#14B8A6]">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-[#002D72] mb-1">Handwriting Score Timeline</h3>
                <p className="text-sm text-[#002D72] opacity-60">Track improvement over time</p>
              </div>
              <Badge variant="success" icon={<TrendingUp className="w-3 h-3" />}>
                +15% This Week
              </Badge>
            </div>
            
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={scoreData}>
                  <defs>
                    <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#14B8A6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#14B8A6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E0F7F7" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#002D72" 
                    style={{ fontSize: '12px' }}
                  />
                  <YAxis 
                    stroke="#002D72" 
                    style={{ fontSize: '12px' }}
                    domain={[0, 100]}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '2px solid #14B8A6',
                      borderRadius: '12px',
                      padding: '8px 12px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#14B8A6" 
                    strokeWidth={3}
                    fill="url(#scoreGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </motion.div>
        
        {/* Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-white to-[#E8F4FF] border-2 border-[#3D8BFF]">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#3D8BFF] to-[#14B8A6] flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-[#002D72] mb-1">Skills Breakdown</h3>
                <p className="text-sm text-[#002D72] opacity-60">Performance by category</p>
              </div>
            </div>
            
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E8F4FF" />
                  <XAxis 
                    dataKey="category" 
                    stroke="#002D72" 
                    style={{ fontSize: '11px' }}
                  />
                  <YAxis 
                    stroke="#002D72" 
                    style={{ fontSize: '12px' }}
                    domain={[0, 100]}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '2px solid #3D8BFF',
                      borderRadius: '12px',
                      padding: '8px 12px'
                    }}
                  />
                  <Bar 
                    dataKey="score" 
                    fill="url(#barGradient)"
                    radius={[8, 8, 0, 0]}
                  />
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3D8BFF" />
                      <stop offset="100%" stopColor="#14B8A6" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </motion.div>
        
        {/* Difficulty Level Changes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-[#FFF9E6] to-[#FFE8CC] border-2 border-[#FFD23F]">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#FFD23F] flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-[#002D72]" />
              </div>
              <div>
                <h3 className="text-[#002D72] mb-1">Difficulty Progression</h3>
                <p className="text-sm text-[#002D72] opacity-60">Adaptive learning path</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-white rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#7BC950] flex items-center justify-center text-white text-sm">
                    1
                  </div>
                  <div>
                    <p className="text-[#002D72]">Basic Level</p>
                    <p className="text-xs text-[#002D72] opacity-60">Nov 10-14</p>
                  </div>
                </div>
                <CheckCircle className="w-5 h-5 text-[#7BC950]" />
              </div>
              
              <div className="flex items-center justify-between p-3 bg-white rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#3D8BFF] flex items-center justify-center text-white text-sm">
                    2
                  </div>
                  <div>
                    <p className="text-[#002D72]">Intermediate Level</p>
                    <p className="text-xs text-[#002D72] opacity-60">Nov 14-20</p>
                  </div>
                </div>
                <CheckCircle className="w-5 h-5 text-[#3D8BFF]" />
              </div>
              
              <div className="flex items-center justify-between p-3 bg-white rounded-xl border-2 border-[#FFD23F]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#FFD23F] flex items-center justify-center text-[#002D72] text-sm">
                    3
                  </div>
                  <div>
                    <p className="text-[#002D72]">Advanced Level</p>
                    <p className="text-xs text-[#002D72] opacity-60">Started Nov 20</p>
                  </div>
                </div>
                <Badge variant="warning">Current</Badge>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Alerts Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-[#FF9F43]" />
            <h3 className="text-[#002D72]">Alerts & Insights</h3>
          </div>
          
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                <Card 
                  className={`
                    ${alert.type === "warning" 
                      ? "bg-gradient-to-br from-[#FFF4ED] to-[#FFE8D9] border-2 border-[#FF9F43]" 
                      : "bg-gradient-to-br from-[#F0FBE8] to-[#E3F7D4] border-2 border-[#7BC950]"}
                  `}
                >
                  <div className="flex items-start gap-3">
                    <div className={`
                      w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0
                      ${alert.type === "warning" ? "bg-[#FF9F43]" : "bg-[#7BC950]"}
                    `}>
                      {alert.type === "warning" ? (
                        <TrendingDown className="w-5 h-5 text-white" />
                      ) : (
                        <TrendingUp className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-1">
                        <h3 className="text-[#002D72]">{alert.title}</h3>
                        <Badge variant={alert.type === "warning" ? "warning" : "success"}>
                          {alert.type === "warning" ? "Alert" : "Good"}
                        </Badge>
                      </div>
                      <p className="text-sm text-[#002D72] opacity-70 mb-2">
                        {alert.message}
                      </p>
                      <p className="text-xs text-[#002D72] opacity-50">{alert.date}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Export Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card gradient className="border-2 border-[#14B8A6]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#14B8A6] to-[#3D8BFF] flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-[#002D72] mb-1">Detailed Report</h3>
                <p className="text-sm text-[#002D72] opacity-60">
                  Export comprehensive progress report for sharing with teachers or therapists
                </p>
              </div>
              <Button
                variant="primary"
                icon={<Download className="w-4 h-4" />}
                className="bg-gradient-to-r from-[#14B8A6] to-[#3D8BFF]"
              >
                Export PDF
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
