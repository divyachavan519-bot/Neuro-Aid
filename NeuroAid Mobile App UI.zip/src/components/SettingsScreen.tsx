import { useState } from "react";
import { motion } from "motion/react";
import { 
  ArrowLeft, 
  Clock, 
  Bell,
  BellOff,
  AlertCircle,
  CheckCircle,
  Settings as SettingsIcon,
  Timer,
  Volume2,
  VolumeX
} from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Badge } from "./Badge";

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const [practiceDuration, setPracticeDuration] = useState<15 | 20 | 30>(20);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  const alerts = [
    {
      id: 1,
      type: "reminder",
      title: "Daily Practice Reminder",
      message: "Time for today's handwriting practice!",
      time: "4:00 PM daily",
      enabled: true
    },
    {
      id: 2,
      type: "achievement",
      title: "Milestone Achievements",
      message: "Celebrate when your child reaches new milestones",
      enabled: true
    },
    {
      id: 3,
      type: "progress",
      title: "Weekly Progress Updates",
      message: "Get weekly summaries of learning progress",
      time: "Every Sunday at 6:00 PM",
      enabled: true
    }
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F0F3FF] via-[#FDFDFD] to-[#F0FBE8] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#7C3AED] to-[#3D8BFF] pt-12 pb-8 px-6 rounded-b-[3rem] shadow-strong">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <motion.button
              onClick={onBack}
              className="w-10 h-10 rounded-full bg-white bg-opacity-20 backdrop-blur-sm flex items-center justify-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </motion.button>
            <h2 className="text-white flex-1">Parent Settings</h2>
          </div>
          
          <p className="text-white text-opacity-90 text-sm">
            Customize learning experience and manage notifications
          </p>
        </div>
      </div>
      
      <div className="max-w-2xl mx-auto px-6 -mt-8">
        {/* Practice Duration Setting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-white to-[#F0F3FF] border-2 border-[#7C3AED]">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#7C3AED] to-[#3D8BFF] flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-[#002D72] mb-1">Daily Practice Duration</h3>
                <p className="text-sm text-[#002D72] opacity-60">Set target practice time</p>
              </div>
            </div>
            
            <div className="space-y-3">
              {[15, 20, 30].map((duration) => (
                <motion.button
                  key={duration}
                  onClick={() => setPracticeDuration(duration as 15 | 20 | 30)}
                  className={`
                    w-full p-4 rounded-2xl border-2 transition-all
                    ${practiceDuration === duration
                      ? "bg-gradient-to-r from-[#7C3AED] to-[#3D8BFF] border-[#7C3AED] text-white shadow-soft"
                      : "bg-white border-gray-200 text-[#002D72] hover:border-[#7C3AED]"}
                  `}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`
                        w-10 h-10 rounded-full flex items-center justify-center
                        ${practiceDuration === duration
                          ? "bg-white bg-opacity-20"
                          : "bg-[#7C3AED] bg-opacity-10"}
                      `}>
                        <Timer className={`w-5 h-5 ${practiceDuration === duration ? "text-white" : "text-[#7C3AED]"}`} />
                      </div>
                      <div className="text-left">
                        <p className={`${practiceDuration === duration ? "text-white" : "text-[#002D72]"}`}>
                          {duration} Minutes
                        </p>
                        <p className={`text-xs ${practiceDuration === duration ? "text-white text-opacity-80" : "text-[#002D72] opacity-60"}`}>
                          {duration === 15 ? "Quick session" : duration === 20 ? "Recommended" : "Extended practice"}
                        </p>
                      </div>
                    </div>
                    {practiceDuration === duration && (
                      <CheckCircle className="w-5 h-5 text-white" />
                    )}
                  </div>
                </motion.button>
              ))}
            </div>
            
            <div className="mt-4 p-3 bg-[#F0F3FF] rounded-xl">
              <p className="text-xs text-[#002D72] opacity-70">
                💡 Research suggests 20-30 minutes of daily practice yields the best results for children in grades 2-5.
              </p>
            </div>
          </Card>
        </motion.div>
        
        {/* Notifications Toggle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-br from-white to-[#FFF9E6] border-2 border-[#FFD23F]">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className={`
                  w-12 h-12 rounded-full flex items-center justify-center
                  ${notificationsEnabled 
                    ? "bg-gradient-to-br from-[#FFD23F] to-[#FFE066]" 
                    : "bg-gray-300"}
                `}>
                  {notificationsEnabled ? (
                    <Bell className="w-6 h-6 text-[#002D72]" />
                  ) : (
                    <BellOff className="w-6 h-6 text-gray-500" />
                  )}
                </div>
                <div>
                  <h3 className="text-[#002D72] mb-1">Notifications</h3>
                  <p className="text-sm text-[#002D72] opacity-60">
                    {notificationsEnabled ? "Enabled" : "Disabled"}
                  </p>
                </div>
              </div>
              
              <motion.button
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                className={`
                  relative w-16 h-8 rounded-full transition-all
                  ${notificationsEnabled ? "bg-[#7BC950]" : "bg-gray-300"}
                `}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className="absolute top-1 w-6 h-6 bg-white rounded-full shadow-md"
                  animate={{
                    left: notificationsEnabled ? "calc(100% - 28px)" : "4px"
                  }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              </motion.button>
            </div>
            
            {notificationsEnabled && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="pt-4 border-t-2 border-[#FFD23F] border-opacity-30"
              >
                <p className="text-sm text-[#002D72] opacity-70 mb-3">
                  Receive reminders and updates about your child's progress
                </p>
                
                {/* Sound Toggle */}
                <div className="flex items-center justify-between p-3 bg-white rounded-xl">
                  <div className="flex items-center gap-3">
                    {soundEnabled ? (
                      <Volume2 className="w-5 h-5 text-[#FFD23F]" />
                    ) : (
                      <VolumeX className="w-5 h-5 text-gray-400" />
                    )}
                    <span className="text-sm text-[#002D72]">Notification Sound</span>
                  </div>
                  <motion.button
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className={`
                      relative w-12 h-6 rounded-full transition-all
                      ${soundEnabled ? "bg-[#FFD23F]" : "bg-gray-300"}
                    `}
                    whileTap={{ scale: 0.95 }}
                  >
                    <motion.div
                      className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-md"
                      animate={{
                        left: soundEnabled ? "calc(100% - 20px)" : "4px"
                      }}
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  </motion.button>
                </div>
              </motion.div>
            )}
          </Card>
        </motion.div>
        
        {/* Alerts Management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-5 h-5 text-[#3D8BFF]" />
            <h3 className="text-[#002D72]">Alert Preferences</h3>
          </div>
          
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card hoverable className={notificationsEnabled ? "" : "opacity-50"}>
                  <div className="flex items-start gap-3">
                    <div className={`
                      w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0
                      ${alert.type === "reminder" 
                        ? "bg-[#3D8BFF] bg-opacity-10" 
                        : alert.type === "achievement"
                        ? "bg-[#FFD23F] bg-opacity-20"
                        : "bg-[#7BC950] bg-opacity-10"}
                    `}>
                      {alert.type === "reminder" ? (
                        <Clock className="w-5 h-5 text-[#3D8BFF]" />
                      ) : alert.type === "achievement" ? (
                        <CheckCircle className="w-5 h-5 text-[#FFD23F]" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-[#7BC950]" />
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-[#002D72] mb-1">{alert.title}</h3>
                      <p className="text-sm text-[#002D72] opacity-60 mb-2">
                        {alert.message}
                      </p>
                      {alert.time && (
                        <div className="flex items-center gap-2">
                          <Badge variant="info" icon={<Clock className="w-3 h-3" />}>
                            {alert.time}
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    <motion.button
                      disabled={!notificationsEnabled}
                      className={`
                        relative w-12 h-6 rounded-full transition-all flex-shrink-0
                        ${notificationsEnabled && alert.enabled ? "bg-[#7BC950]" : "bg-gray-300"}
                      `}
                      whileTap={{ scale: notificationsEnabled ? 0.95 : 1 }}
                    >
                      <motion.div
                        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-md"
                        animate={{
                          left: notificationsEnabled && alert.enabled ? "calc(100% - 20px)" : "4px"
                        }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </motion.button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Additional Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card gradient className="border-2 border-[#7C3AED]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#7C3AED] to-[#3D8BFF] flex items-center justify-center flex-shrink-0">
                <SettingsIcon className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-[#002D72] mb-1">More Settings</h3>
                <p className="text-sm text-[#002D72] opacity-60">
                  Profile, privacy, and account settings
                </p>
              </div>
              <Button variant="outline" size="sm">
                View All
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
