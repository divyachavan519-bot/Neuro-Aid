import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Star, AlertTriangle, AlertCircle, ArrowRight, TrendingUp } from "lucide-react";
import { Button } from "./Button";
import { Card } from "./Card";
import { Badge } from "./Badge";
import { Mascot } from "./Mascot";

interface RiskResultProps {
  onContinue: () => void;
  riskLevel?: "low" | "medium" | "high";
}

export function RiskResult({ onContinue, riskLevel = "medium" }: RiskResultProps) {
  const [showConfetti, setShowConfetti] = useState(false);
  
  useEffect(() => {
    if (riskLevel === "low") {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);
    }
  }, [riskLevel]);
  
  const riskConfig = {
    low: {
      icon: <Star className="w-16 h-16 text-white" />,
      color: "bg-[#7BC950]",
      gradient: "from-[#7BC950] to-[#9BE276]",
      title: "Low Risk",
      emoji: "🌟",
      message: "Great news! The handwriting shows healthy development.",
      mascotExpression: "happy" as const,
      mascotMessage: "Amazing! Keep up the great work!",
      confidence: 92
    },
    medium: {
      icon: <AlertCircle className="w-16 h-16 text-[#002D72]" />,
      color: "bg-[#FFD23F]",
      gradient: "from-[#FFD23F] to-[#FFE066]",
      title: "Moderate Risk",
      emoji: "🟡",
      message: "Some signs detected. Early intervention can make a big difference!",
      mascotExpression: "thinking" as const,
      mascotMessage: "Let's work together to improve!",
      confidence: 78
    },
    high: {
      icon: <AlertTriangle className="w-16 h-16 text-white" />,
      color: "bg-[#FF6B6B]",
      gradient: "from-[#FF6B6B] to-[#FF8F8F]",
      title: "Higher Risk",
      emoji: "🔴",
      message: "Several indicators found. We recommend personalized exercises and guidance.",
      mascotExpression: "concerned" as const,
      mascotMessage: "Don't worry, we're here to help!",
      confidence: 85
    }
  };
  
  const config = riskConfig[riskLevel];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E8F4FF] via-[#FDFDFD] to-[#FFF9E6] p-6 pt-12 relative overflow-hidden">
      {/* Confetti for low risk */}
      <AnimatePresence>
        {showConfetti && (
          <>
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ 
                  top: "-10%", 
                  left: `${Math.random() * 100}%`,
                  rotate: 0
                }}
                animate={{ 
                  top: "110%",
                  rotate: 360
                }}
                exit={{ opacity: 0 }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  delay: Math.random() * 0.5,
                  ease: "linear"
                }}
                className="absolute w-3 h-3 rounded-full pointer-events-none"
                style={{
                  background: ["#3D8BFF", "#FFD23F", "#7BC950", "#FF9F43"][Math.floor(Math.random() * 4)]
                }}
              />
            ))}
          </>
        )}
      </AnimatePresence>
      
      <div className="max-w-2xl mx-auto relative z-10">
        {/* Result Badge */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="flex justify-center mb-8"
        >
          <div className={`w-40 h-40 rounded-full bg-gradient-to-br ${config.gradient} shadow-strong flex items-center justify-center relative`}>
            {config.icon}
            <motion.div
              className="absolute inset-0 rounded-full"
              animate={{
                boxShadow: [
                  "0 0 0 0 rgba(61, 139, 255, 0.4)",
                  "0 0 0 20px rgba(61, 139, 255, 0)",
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        </motion.div>
        
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-3">
            <h1 className="text-[#002D72]">{config.title}</h1>
            <span className="text-4xl">{config.emoji}</span>
          </div>
          <p className="text-[#002D72] opacity-70 max-w-md mx-auto">
            {config.message}
          </p>
        </motion.div>
        
        {/* Mascot */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="flex justify-center mb-8"
        >
          <Mascot 
            expression={config.mascotExpression}
            message={config.mascotMessage}
            size="md"
          />
        </motion.div>
        
        {/* Confidence Score */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card gradient className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#3D8BFF] flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-[#002D72]">Confidence Score</h3>
                  <p className="text-sm text-[#002D72] opacity-60">
                    AI Analysis Accuracy
                  </p>
                </div>
              </div>
              <div className="text-3xl text-[#3D8BFF]">
                {config.confidence}%
              </div>
            </div>
            
            <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-[#3D8BFF] to-[#5BA4FF]"
                initial={{ width: 0 }}
                animate={{ width: `${config.confidence}%` }}
                transition={{ delay: 0.9, duration: 1, ease: "easeOut" }}
              />
            </div>
          </Card>
        </motion.div>
        
        {/* Key Findings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
        >
          <Card className="mb-6">
            <h3 className="text-[#002D72] mb-4">Key Findings</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#E8F4FF] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-sm">1</span>
                </div>
                <p className="text-sm text-[#002D72] opacity-70">
                  Letter formation patterns analyzed across multiple samples
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#E8F4FF] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-sm">2</span>
                </div>
                <p className="text-sm text-[#002D72] opacity-70">
                  Spacing and alignment consistency evaluated
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#E8F4FF] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-sm">3</span>
                </div>
                <p className="text-sm text-[#002D72] opacity-70">
                  Reversal and mirroring indicators checked
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
        
        {/* Next Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1 }}
        >
          <Button
            onClick={onContinue}
            variant={riskLevel === "low" ? "success" : riskLevel === "medium" ? "warning" : "primary"}
            size="lg"
            icon={<ArrowRight className="w-5 h-5" />}
            className="w-full"
          >
            {riskLevel === "low" 
              ? "View Progress Dashboard" 
              : "Start Personalized Exercises"}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
