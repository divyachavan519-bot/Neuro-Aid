import { motion } from "motion/react";
import { ReactNode } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  hoverable?: boolean;
  gradient?: boolean;
}

export function Card({ 
  children, 
  className = "", 
  onClick, 
  hoverable = false,
  gradient = false 
}: CardProps) {
  return (
    <motion.div
      onClick={onClick}
      className={`
        bg-white rounded-3xl p-6 shadow-soft
        ${hoverable ? "cursor-pointer hover:shadow-medium" : ""}
        ${gradient ? "bg-gradient-to-br from-[#E8F4FF] to-white" : ""}
        ${className}
      `}
      whileHover={hoverable ? { scale: 1.02, y: -4 } : {}}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {children}
    </motion.div>
  );
}
