import { motion } from "motion/react";
import { ReactNode } from "react";

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "success" | "warning" | "outline";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  disabled?: boolean;
  className?: string;
}

export function Button({ 
  children, 
  onClick, 
  variant = "primary", 
  size = "md",
  icon,
  disabled = false,
  className = ""
}: ButtonProps) {
  const baseStyles = "rounded-full font-bold flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-[#3D8BFF] text-white hover:bg-[#2E7AEE] shadow-soft hover:shadow-medium",
    success: "bg-[#7BC950] text-white hover:bg-[#6AB840] shadow-soft hover:shadow-medium",
    warning: "bg-[#FFD23F] text-[#002D72] hover:bg-[#FFCA1F] shadow-soft hover:shadow-medium",
    outline: "bg-white border-2 border-[#3D8BFF] text-[#3D8BFF] hover:bg-[#E8F4FF] shadow-soft"
  };
  
  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };
  
  return (
    <motion.button
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
    >
      {icon && <span className="inline-flex">{icon}</span>}
      {children}
    </motion.button>
  );
}
